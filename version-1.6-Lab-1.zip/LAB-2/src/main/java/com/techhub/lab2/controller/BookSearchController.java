package com.techhub.lab2.controller;

import java.time.LocalTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.lab2.vo.BookInfo;

@RestController
public class BookSearchController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookSearchController.class);

	@Value("${server.port}")
	private String serverPort;
	
	@Value("${techhub.booksearch.message}")
	private String searchMessage;

	@GetMapping("/get-book")
	public BookInfo getBook() {
		LOGGER.info("---BookSearchController---getBook()---"); 
		BookInfo bookInfo = new BookInfo();
		bookInfo.setBookId(1001);
		bookInfo.setBookName("Master Spring MicroServices");
		bookInfo.setAuthor("Ram Niwash");
		bookInfo.setInfo("LAB-2 (BookSearch) Port Number = "+this.serverPort+", Message = "+this.searchMessage);
		LOGGER.info("LAB-2 (BookSearch) Exiting :  TIME : "+LocalTime.now());
		return bookInfo;
	}
}
