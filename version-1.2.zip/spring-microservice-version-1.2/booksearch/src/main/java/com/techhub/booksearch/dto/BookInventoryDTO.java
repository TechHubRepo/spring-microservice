package com.techhub.booksearch.dto;

import java.io.Serializable;

public class BookInventoryDTO  implements Serializable {

	private static final long serialVersionUID = 1L;

	private int bookId;

	private int booksAvailable;

	public BookInventoryDTO() {
		super();
	}

	public BookInventoryDTO(int bookId, Integer booksAvailable) {
		super();
		this.bookId = bookId;
		this.booksAvailable = booksAvailable;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getBooksAvailable() {
		return booksAvailable;
	}

	public void setBooksAvailable(int booksAvailable) {
		this.booksAvailable = booksAvailable;
	}

	@Override
	public String toString() {
		return "BookInventory [bookId=" + bookId + ", booksAvailable=" + booksAvailable + "]";
	}
}
