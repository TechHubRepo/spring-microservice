package com.techhub.booksearch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.techhub.booksearch.model.BookRating;

@Repository
public interface BookRatingRepository extends JpaRepository<BookRating, Integer>{

}
