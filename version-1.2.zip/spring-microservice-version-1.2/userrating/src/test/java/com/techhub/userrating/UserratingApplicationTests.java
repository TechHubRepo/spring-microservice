package com.techhub.userrating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserratingApplicationTests {

	@Test
	void contextLoads() {
	}

}
