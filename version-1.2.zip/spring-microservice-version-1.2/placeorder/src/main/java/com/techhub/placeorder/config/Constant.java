package com.techhub.placeorder.config;

public class Constant {

	private Constant() {
	}

	/** Book Inventory exchange, query and key */

	public static final String BOOK_INV_EXCHANGE_NAME = "my-book-inv-exc";

	public static final String BOOK_INV_QUEUE_NAME = "my-book-inv-queue";

	public static final String BOOK_INV_ROUTING_KEY = "my.book.inv.key";
	
	/** Book Order exchange, query and key */

	public static final String BOOK_ORDER_EXCHANGE_NAME = "my-book-order-exc";

	public static final String BOOK_ORDER_QUEUE_NAME = "my-book-order-queue";

	public static final String BOOK_ORDER_ROUTING_KEY = "my.book.order.key";
	
}
