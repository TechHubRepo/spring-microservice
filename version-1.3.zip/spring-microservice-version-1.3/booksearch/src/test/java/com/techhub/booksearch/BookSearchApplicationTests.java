package com.techhub.booksearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
