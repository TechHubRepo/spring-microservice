package com.techhub.booksearch.util;

import java.math.BigInteger;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.techhub.booksearch.dto.BookPriceDTO;

@FeignClient(name = "bookprice", url = "http://localhost:4000")
public interface BookPriceProxy {

	@GetMapping(value = "/get-book-price/{bookId}")
	public BookPriceDTO getBookPrice(@PathVariable BigInteger bookId);

	@GetMapping(value = "/get-book-offer-price/{bookId}")
	public double getBookOfferPrice(@PathVariable BigInteger bookId);
}
