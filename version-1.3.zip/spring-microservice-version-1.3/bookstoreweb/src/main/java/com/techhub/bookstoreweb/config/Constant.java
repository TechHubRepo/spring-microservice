package com.techhub.bookstoreweb.config;

public final class Constant {

	private Constant() {
	}

	/** User Rating exchange, query and key */

	public static final String USER_RATING_EXCHANGE_NAME = "my-user-rating-exc";

	public static final String USER_RATING_QUEUE_NAME = "my-user-rating-queue";

	public static final String USER_RATING_ROUTING_KEY = "my.user.rating.key";
	
	/** Book Order exchange, query and key */

	public static final String BOOK_ORDER_EXCHANGE_NAME = "my-book-order-exc";

	public static final String BOOK_ORDER_QUEUE_NAME = "my-book-order-queue";

	public static final String BOOK_ORDER_ROUTING_KEY = "my.book.order.key";

}
