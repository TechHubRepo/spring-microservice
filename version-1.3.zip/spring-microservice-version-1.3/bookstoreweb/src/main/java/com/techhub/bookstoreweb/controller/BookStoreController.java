package com.techhub.bookstoreweb.controller;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.techhub.bookstoreweb.dto.BookDTO;
import com.techhub.bookstoreweb.dto.BookInfo;
import com.techhub.bookstoreweb.dto.OrderDTO;
import com.techhub.bookstoreweb.service.BookStoreService;
import com.techhub.userrating.dto.UserRatingDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class BookStoreController {

	/** The USER_ID */
	private static final String USER_ID = "U1100";

	@Autowired
	private BookStoreService bookStoreService;

	@GetMapping("/")
	public String showIndexPage(Model model, HttpSession session) {
		return "redirect:/show-books";
	}

	@GetMapping("/show-books")
	public String showBooksList(HttpServletRequest request, HttpSession session, Model model) {
		List<String> authorNames = bookStoreService.getAuthorsList();
		List<String> categoryNames = bookStoreService.getCategoryList();
		session.setAttribute("author_names", authorNames);
		session.setAttribute("category_names", categoryNames);
		session.setAttribute("user_id", USER_ID);
		if (session.getAttribute("my_cart") == null) {
			session.setAttribute("my_cart", new LinkedHashMap<Integer, BookDTO>());
		}
		String author = request.getParameter("author");
		String category = request.getParameter("category");
		Collection<BookDTO> books = bookStoreService.getMyBooks(author, category);
		session.setAttribute("books", books);
		return "show-books";
	}

	@GetMapping("/show-book-info")
	public String showBookFullInfo(@RequestParam("bookId") String bookId, HttpSession session,
			HttpServletRequest request) {
		BookInfo bookInfo = bookStoreService.getBookInfoByBookId(Integer.valueOf(bookId));
		request.setAttribute("book_Info", bookInfo);
		return "show-book-Info";
	}

	@SuppressWarnings("unchecked")
	@PostMapping("/add-to-cart")
	public String addBookToCart(@RequestParam("bookId") String bookId, HttpSession session) {
		BookDTO mybook = bookStoreService.getBookByBookId(Integer.valueOf(bookId));
		Map<Integer, BookDTO> myCart = (Map<Integer, BookDTO>) session.getAttribute("my_cart");
		myCart.put(Integer.valueOf(bookId), mybook);
		return "show-books";
	}

	@GetMapping("/show-my-cart")
	public String showCart(HttpServletRequest request, HttpSession session) {
		if (session.getAttribute("my_cart") == null) {
			session.setAttribute("my_cart", new LinkedHashMap<Integer, BookDTO>());
		}
		session.setAttribute("user_id", USER_ID);
		return "my-cart";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/remove-from-cart")
	public String removeFromCart(@RequestParam("bookId") String bookId, HttpSession session) {
		Object obj = session.getAttribute("my_cart");
		Map<Integer, BookDTO> myCart = (Map<Integer, BookDTO>) obj;
		myCart.remove(Integer.valueOf(bookId));
		return "redirect:/show-my-cart";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/place-my-order")
	public String placeMyOrder(HttpServletRequest request, HttpSession session) {
		Object obj = session.getAttribute("my_cart");
		if (obj != null) {
			Map<Integer, BookDTO> myCart = (Map<Integer, BookDTO>) obj;
			if (myCart.size() > 0) {
				bookStoreService.placeOrder(myCart, USER_ID);
				myCart.clear();
				request.setAttribute("msg", "Your order is placed successfully, Thank you for shoping with us.");
			}
		}
		return "success";
	}

	@GetMapping("/show-my-orders")
	public String showMyOrder(HttpServletRequest request) {
		List<OrderDTO> myOrders = this.bookStoreService.getMyOrders(USER_ID);
		request.setAttribute("my_orders", myOrders);
		return "show-my-orders";
	}

	@GetMapping("/book-rating")
	public String showRatingsForm(Model model) {
		UserRatingDTO userRatingDTO = new UserRatingDTO();
		userRatingDTO.setUserId(USER_ID);
		userRatingDTO.setRating(0);
		userRatingDTO.setBookId(0);
		model.addAttribute("user_rating", userRatingDTO);
		return "book-rating";
	}

	@PostMapping("/add-book-rating")
	public String addMyRating(@ModelAttribute("user_rating") UserRatingDTO userRatingDTO, HttpServletRequest request) {
		System.out.println("BookStoreController -> add-book-rating -> addMyRating");
		System.out.println("UserRatingDTO : "+userRatingDTO);
		userRatingDTO.setUserId(USER_ID);
		bookStoreService.addUserRating(userRatingDTO);
		request.setAttribute("msg", "Your rating is provided thank you.");
		return "success";
	}

	@GetMapping("/show-my-rating")
	public String showMyRatingsList(Model model, HttpServletRequest request) {
		List<UserRatingDTO> myRatings = bookStoreService.getMyRatings(USER_ID);
		request.setAttribute("my_ratings", myRatings);
		return "my-ratings";
	}
}