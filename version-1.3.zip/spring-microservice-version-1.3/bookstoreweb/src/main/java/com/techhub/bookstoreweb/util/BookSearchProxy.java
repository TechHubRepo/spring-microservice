package com.techhub.bookstoreweb.util;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.techhub.bookstoreweb.dto.BookDTO;
import com.techhub.bookstoreweb.dto.BookInfo;

@FeignClient(name = "booksearch", url = "http://localhost:5000")
public interface BookSearchProxy {

	@GetMapping("/search-books/{author}/{category}")
	public List<BookDTO> searchBooks(@PathVariable String author, @PathVariable String category) ;

	@GetMapping("/get-book/{bookId}")
	public BookInfo getBookById(@PathVariable Integer bookId) ;
}
