package com.techhub.bookprice.model;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "my_book_price", schema = "book_price")
public class BookPrice {

	@Id
	@Column(name = "BOOK_ID")
	private BigInteger bookId;

	@Column(name = "BOOK_PRICE")
	private int bookPrice;

	@Column(name = "BOOK_OFFER")
	private byte bookOffer;

	public BookPrice() {
		super();
	}

	public BookPrice(BigInteger bookId, int bookPrice, byte bookOffer) {
		super();
		this.bookId = bookId;
		this.bookPrice = bookPrice;
		this.bookOffer = bookOffer;
	}

	public BigInteger getBookId() {
		return bookId;
	}

	public void setBookId(BigInteger bookId) {
		this.bookId = bookId;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public byte getBookOffer() {
		return bookOffer;
	}

	public void setBookOffer(byte bookOffer) {
		this.bookOffer = bookOffer;
	}

	@Override
	public String toString() {
		return "BookPrice [bookId=" + bookId + ", bookPrice=" + bookPrice + ", bookOffer=" + bookOffer + "]";
	}
}
