package com.techhub.booksearch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.techhub.booksearch.model.BookInventory;

@Repository
public interface BookInventoryRepository extends JpaRepository<BookInventory, Integer> {

}
