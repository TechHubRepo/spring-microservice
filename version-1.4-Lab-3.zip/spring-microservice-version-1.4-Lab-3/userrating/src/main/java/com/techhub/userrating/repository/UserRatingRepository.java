package com.techhub.userrating.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.techhub.userrating.model.UserRating;

@Repository
public interface UserRatingRepository extends JpaRepository<UserRating, Integer> {
	
	public List<UserRating> findUserRatingByBookId(Integer bookId);

	public List<UserRating> findUserRatingByUserId(String userId);
}
