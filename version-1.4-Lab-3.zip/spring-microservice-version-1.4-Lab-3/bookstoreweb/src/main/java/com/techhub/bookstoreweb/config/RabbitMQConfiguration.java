package com.techhub.bookstoreweb.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.ExchangeBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfiguration {

	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	/** User Rating exchange, query and key configuration */

	@Bean(name = "userRatingExchange")
	public DirectExchange userRatingExchange() {
		return ExchangeBuilder.directExchange(Constant.USER_RATING_EXCHANGE_NAME).build();
	}

	@Bean(name = "userRatingQueue")
	public Queue userRatingQueue() {
		return QueueBuilder.durable(Constant.USER_RATING_QUEUE_NAME).build();
	}

	@Bean
	public Binding userRatingBinding(@Qualifier("userRatingQueue") Queue queue,
			@Qualifier("userRatingExchange") DirectExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange).with(Constant.USER_RATING_ROUTING_KEY);
	}
	
	/** Book Order exchange, query and key configuration */

	@Bean(name = "bookOrderExchange")
	public DirectExchange bookOrderExchange() {
		return ExchangeBuilder.directExchange(Constant.BOOK_ORDER_EXCHANGE_NAME).build();
	}

	@Bean(name = "bookOrderQueue")
	public Queue bookOrderQueue() {
		return QueueBuilder.durable(Constant.BOOK_ORDER_QUEUE_NAME).build();
	}

	@Bean
	public Binding bookOrderBinding(@Qualifier("bookOrderQueue") Queue queue,
			@Qualifier("bookOrderExchange") DirectExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange).with(Constant.BOOK_ORDER_ROUTING_KEY);
	}
}
