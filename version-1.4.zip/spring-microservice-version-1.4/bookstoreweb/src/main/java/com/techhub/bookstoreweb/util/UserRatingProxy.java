package com.techhub.bookstoreweb.util;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.techhub.userrating.dto.UserRatingDTO;

@FeignClient(name = "userrating")
public interface UserRatingProxy {

	@GetMapping("/user-ratings/{userId}")
	public List<UserRatingDTO> getUserRatingByUserId(@PathVariable String userId);
}
