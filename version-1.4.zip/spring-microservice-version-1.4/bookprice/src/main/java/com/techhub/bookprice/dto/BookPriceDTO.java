package com.techhub.bookprice.dto;

import java.math.BigInteger;

public class BookPriceDTO {

	private BigInteger bookId;

	private int bookPrice;

	private byte bookOffer;

	public BookPriceDTO() {
		super();
	}

	public BookPriceDTO(BigInteger bookId, int bookPrice, byte bookOffer) {
		super();
		this.bookId = bookId;
		this.bookPrice = bookPrice;
		this.bookOffer = bookOffer;
	}

	public BigInteger getBookId() {
		return bookId;
	}

	public void setBookId(BigInteger bookId) {
		this.bookId = bookId;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public byte getBookOffer() {
		return bookOffer;
	}

	public void setBookOffer(byte bookOffer) {
		this.bookOffer = bookOffer;
	}

	@Override
	public String toString() {
		return "BookPrice [bookId=" + bookId + ", bookPrice=" + bookPrice + ", bookOffer=" + bookOffer + "]";
	}
}
