package com.techhub.userrating.model;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "my_user_ratings", schema = "user_rating")
public class UserRating {

	@Id
	@Column(name = "RATING_ID")
	private BigInteger ratingId;

	@Column(name = "BOOK_ID")
	private Integer bookId;

	@Column(name = "USER_ID")
	private String userId;

	@Column(name = "RATING")
	private double rating;

	@Column(name = "REVIEW")
	private String review;

	public UserRating() {
		super();
	}

	public UserRating(BigInteger ratingId, Integer bookId, String userId, double rating, String review) {
		super();
		this.ratingId = ratingId;
		this.bookId = bookId;
		this.userId = userId;
		this.rating = rating;
		this.review = review;
	}

	public BigInteger getRatingId() {
		return ratingId;
	}

	public void setRatingId(BigInteger ratingId) {
		this.ratingId = ratingId;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	@Override
	public String toString() {
		return "UserRating [ratingId=" + ratingId + ", bookId=" + bookId + ", userId=" + userId + ", rating=" + rating
				+ ", review=" + review + "]";
	}
}
