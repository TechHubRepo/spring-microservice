package com.techhub.userrating.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.booksearch.dto.BookRatingDTO;
import com.techhub.userrating.dto.UserRatingDTO;
import com.techhub.userrating.service.RatingService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/user-rating")
public class RatingController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RatingController.class);

	@Autowired
	private RatingService ratingService;

	@GetMapping("/user-ratings/{userId}")
	public List<UserRatingDTO> getUserRatingByUserId(@PathVariable String userId) {
		LOGGER.info("Entering | Class = RatingController | method = getUserRatingByUserId");
		try {
			return ratingService.getUserRatingByUserId(userId);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return List.of();
	}

	@GetMapping("/book-ratings/{bookId}")
	public BookRatingDTO getBookRatingByBookId(@PathVariable Integer bookId) {
		LOGGER.info("Entering | Class = RatingController | method = getBookRatingByBookId");
		try {
			return ratingService.getBookRatingByBookId(bookId);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return new BookRatingDTO();
	}
}
