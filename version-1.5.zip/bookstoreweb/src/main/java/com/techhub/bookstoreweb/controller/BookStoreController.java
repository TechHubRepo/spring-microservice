package com.techhub.bookstoreweb.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.techhub.bookstoreweb.dto.BookDTO;
import com.techhub.bookstoreweb.dto.BookInfo;
import com.techhub.bookstoreweb.dto.OrderDTO;
import com.techhub.bookstoreweb.service.BookStoreService;
import com.techhub.userrating.dto.UserRatingDTO;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/")
public class BookStoreController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookStoreController.class);

	/** The USER_ID */
	private static final String USER_ID = "U1100";

	@Autowired
	private BookStoreService bookStoreService;

	@GetMapping("/")
	public String showIndexPage(Model model, HttpSession session) {
		LOGGER.info("Entering | Class = BookStoreController | method = showIndexPage");
		return "redirect:/show-books";
	}

	@GetMapping("/show-books")
	@CircuitBreaker(name = "showBooksList", fallbackMethod = "showBooksListFallback")
	public String showBooksList(HttpServletRequest request, HttpSession session, Model model) {
		LOGGER.info("Entering | Class = BookStoreController | method = showBooksList");

		List<String> authorNames = bookStoreService.getAuthorsList();
		List<String> categoryNames = bookStoreService.getCategoryList();
		session.setAttribute("author_names", authorNames);
		session.setAttribute("category_names", categoryNames);
		session.setAttribute("user_id", USER_ID);
		if (session.getAttribute("my_cart") == null) {
			session.setAttribute("my_cart", new LinkedHashMap<Integer, BookDTO>());
		}
		String author = request.getParameter("author");
		String category = request.getParameter("category");
		Collection<BookDTO> books = bookStoreService.getMyBooks(author, category);
		session.setAttribute("books", books);

		return "show-books";
	}

	public String showBooksListFallback(HttpServletRequest request, HttpSession session, Model model,
			Throwable throwable) {
		LOGGER.info("Entering | Class = BookStoreController | method = showBooksListFallback");
		LOGGER.error(throwable.getMessage(), throwable);
		List<BookDTO> books = new ArrayList<>();
		session.setAttribute("books", books);
		return "show-books";
	}

	@GetMapping("/show-book-info")
	public String showBookFullInfo(@RequestParam("bookId") String bookId, HttpSession session,
			HttpServletRequest request) {
		LOGGER.info("Entering | Class = BookStoreController | method = showBookFullInfo");
		try {
			BookInfo bookInfo = bookStoreService.getBookInfoByBookId(Integer.valueOf(bookId));
			request.setAttribute("book_Info", bookInfo);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "show-book-Info";
	}

	@SuppressWarnings("unchecked")
	@PostMapping("/add-to-cart")
	public String addBookToCart(@RequestParam("bookId") String bookId, HttpSession session) {
		LOGGER.info("Entering | Class = BookStoreController | method = addBookToCart");
		try {
			BookDTO mybook = bookStoreService.getBookByBookId(Integer.valueOf(bookId));
			Map<Integer, BookDTO> myCart = (Map<Integer, BookDTO>) session.getAttribute("my_cart");
			myCart.put(Integer.valueOf(bookId), mybook);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "show-books";
	}

	@GetMapping("/show-my-cart")
	public String showCart(HttpServletRequest request, HttpSession session) {
		LOGGER.info("Entering | Class = BookStoreController | method = showCart");
		try {
			if (session.getAttribute("my_cart") == null) {
				session.setAttribute("my_cart", new LinkedHashMap<Integer, BookDTO>());
			}
			session.setAttribute("user_id", USER_ID);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "my-cart";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/remove-from-cart")
	public String removeFromCart(@RequestParam("bookId") String bookId, HttpSession session) {
		LOGGER.info("Entering | Class = BookStoreController | method = removeFromCart");
		try {
			Object obj = session.getAttribute("my_cart");
			Map<Integer, BookDTO> myCart = (Map<Integer, BookDTO>) obj;
			myCart.remove(Integer.valueOf(bookId));
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "redirect:/show-my-cart";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/place-my-order")
	public String placeMyOrder(HttpServletRequest request, HttpSession session) {
		LOGGER.info("Entering | Class = BookStoreController | method = placeMyOrder");
		try {
			Object obj = session.getAttribute("my_cart");
			if (obj != null) {
				Map<Integer, BookDTO> myCart = (Map<Integer, BookDTO>) obj;
				if (myCart.size() > 0) {
					bookStoreService.placeOrder(myCart, USER_ID);
					myCart.clear();
					request.setAttribute("msg", "Your order is placed successfully, Thank you for shoping with us.");
				}
			}
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "success";
	}

	@GetMapping("/show-my-orders")
	public String showMyOrder(HttpServletRequest request) {
		LOGGER.info("Entering | Class = BookStoreController | method = showMyOrder");
		try {
			List<OrderDTO> myOrders = this.bookStoreService.getMyOrders(USER_ID);
			request.setAttribute("my_orders", myOrders);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "show-my-orders";
	}

	@GetMapping("/book-rating")
	public String showRatingsForm(Model model) {
		LOGGER.info("Entering | Class = BookStoreController | method = showRatingsForm");
		try {
			UserRatingDTO userRatingDTO = new UserRatingDTO();
			userRatingDTO.setUserId(USER_ID);
			userRatingDTO.setRating(0);
			userRatingDTO.setBookId(0);
			model.addAttribute("user_rating", userRatingDTO);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "book-rating";
	}

	@PostMapping("/add-book-rating")
	public String addMyRating(@ModelAttribute("user_rating") UserRatingDTO userRatingDTO, HttpServletRequest request) {
		LOGGER.info("Entering | Class = BookStoreController | method = addMyRating");
		try {
			userRatingDTO.setUserId(USER_ID);
			bookStoreService.addUserRating(userRatingDTO);
			request.setAttribute("msg", "Your rating is provided thank you.");
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "success";
	}

	@GetMapping("/show-my-rating")
	public String showMyRatingsList(Model model, HttpServletRequest request) {
		LOGGER.info("Entering | Class = BookStoreController | method = showMyRatingsList");
		try {
			List<UserRatingDTO> myRatings = bookStoreService.getMyRatings(USER_ID);
			request.setAttribute("my_ratings", myRatings);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return "my-ratings";
	}
}