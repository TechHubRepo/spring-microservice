package com.techhub.bookprice.service;

import java.math.BigInteger;

import com.techhub.bookprice.dto.BookPriceDTO;

public interface BookPriceService {

	public BookPriceDTO getBookPrice(BigInteger bookId);
	
	public double getBookOfferedPrice(BigInteger bookId);

}
