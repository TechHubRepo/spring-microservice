package com.techhub.bookprice.controller;

import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.bookprice.dto.BookPriceDTO;
import com.techhub.bookprice.service.BookPriceService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/book-price")
public class BookPriceController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookPriceController.class);

	@Autowired
	private BookPriceService bookPriceService;

	@GetMapping(value = "/get-book-price/{bookId}")
	public BookPriceDTO getBookPrice(@PathVariable BigInteger bookId) {
		LOGGER.info("Entering | Class = BookPriceController | method = getBookPrice");
		try {
			return bookPriceService.getBookPrice(bookId);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
			return new BookPriceDTO();
		}
	}

	@GetMapping(value = "/get-book-offer-price/{bookId}")
	public double getBookOfferPrice(@PathVariable BigInteger bookId) {
		LOGGER.info("Entering | Class = BookPriceController | method = getBookOfferPrice");
		try {
			return bookPriceService.getBookOfferedPrice(bookId);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
			return 0;
		}
	}
}
