package com.techhub.booksearch.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.booksearch.dto.BookDTO;
import com.techhub.booksearch.dto.BookInfo;
import com.techhub.booksearch.service.BookService;

@CrossOrigin(origins = "*", allowedHeaders = "*", methods = { RequestMethod.GET, RequestMethod.PUT })
@RestController
@RequestMapping("/book-search")
public class BookController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookController.class);

	@Autowired
	private BookService bookService;

	@GetMapping("/search-books/{author}/{category}")
	public List<BookDTO> searchBooks(@PathVariable String author, @PathVariable String category) {
		LOGGER.info("Entering | Class = BookController | method = searchBooks");
		try {
			return bookService.getBooks(author, category);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
			return List.of();
		}
	}

	@GetMapping("/get-book/{bookId}")
	public BookInfo getBookById(@PathVariable Integer bookId) {
		LOGGER.info("Entering | Class = BookController | method = getBookById");
		try {
			return bookService.getBookInfo(bookId);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
			return new BookInfo();
		}
	}
}
