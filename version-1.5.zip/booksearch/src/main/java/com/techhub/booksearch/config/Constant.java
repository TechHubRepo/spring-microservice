package com.techhub.booksearch.config;

public final class Constant {

	private Constant() {
	}

	/** Book Rating exchange, query and key */
	
	public static final String BOOK_RATING_EXCHANGE_NAME = "my-book-rating-exc";

	public static final String BOOK_RATING_QUEUE_NAME = "my-book-rating-queue";

	public static final String BOOK_RATING_ROUTING_KEY = "my.book.rating.key";
	
	/** Book Inventory exchange, query and key */
	
	public static final String BOOK_INV_EXCHANGE_NAME = "my-book-inv-exc";

	public static final String BOOK_INV_QUEUE_NAME = "my-book-inv-queue";

	public static final String BOOK_INV_ROUTING_KEY = "my.book.inv.key";
}
