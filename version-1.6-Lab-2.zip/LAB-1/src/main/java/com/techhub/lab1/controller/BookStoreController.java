package com.techhub.lab1.controller;

import java.time.LocalTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.lab1.proxy.Lab2Proxy;
import com.techhub.lab1.vo.BookInfo;

@RestController
@RefreshScope
public class BookStoreController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BookStoreController.class);

	@Value("${server.port}")
	private String serverPort;
	
	@Value("${techhub.bookstore.message}")
	private String message;

	@Autowired
	private Lab2Proxy lab2Proxy;

	@GetMapping("/mybook")
	public BookInfo getMyBooks() {
		LOGGER.info("PORT = "+this.serverPort+" ---> BookStoreController  ----> getMyBooks");
		BookInfo booksInfo = lab2Proxy.getBook();
		String info = "LAB-1 (BookStore) port number is " + this.serverPort +", Message = "+ this.message+" || " + booksInfo.getInfo();
		booksInfo.setInfo(info);
		LOGGER.info("LAB-1(BookStore) Exiting :  TIME : "+LocalTime.now());
		return booksInfo;
	}
}
