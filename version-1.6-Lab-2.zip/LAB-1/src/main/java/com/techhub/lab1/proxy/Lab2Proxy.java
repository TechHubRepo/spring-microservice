package com.techhub.lab1.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.techhub.lab1.vo.BookInfo;

@FeignClient("LAB-2")
public interface Lab2Proxy {

	@GetMapping("/get-book")
	public BookInfo getBook();
}
