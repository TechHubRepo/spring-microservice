package com.techhub.booksearch.service;

import java.util.List;

import com.techhub.booksearch.dto.BookDTO;
import com.techhub.booksearch.dto.BookInfo;
import com.techhub.booksearch.dto.BookInventoryDTO;
import com.techhub.booksearch.dto.BookRatingDTO;

public interface BookService {
	
	public List<BookDTO> getBooks(String author, String category);

	public BookInfo getBookInfo(Integer bookId);

	public void updateBookRating(BookRatingDTO bookRating);

	public void updateBookInventory(BookInventoryDTO bookInventory);
}
