package com.techhub.bookstoreweb.service;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.techhub.bookstoreweb.adaptor.BookAdaptor;
import com.techhub.bookstoreweb.dto.BookDTO;
import com.techhub.bookstoreweb.dto.BookInfo;
import com.techhub.bookstoreweb.dto.OrderDTO;
import com.techhub.bookstoreweb.dto.OrderInfo;
import com.techhub.bookstoreweb.dto.OrderItemDTO;
import com.techhub.bookstoreweb.dto.UserRatingDTO;

@Service
public class BookStoreServiceImpl implements BookStoreService {

	private static final String BOOK_SEARCH_END_URI = "http://localhost:5000/search-books/";

	private static final String GET_BOOK_BY_BOOK_ID_URI = "http://localhost:5000/get-book/";

	private static final String BOOK_PRICE_END_URI = "http://localhost:4000/get-book-offer-price/";

	private static final String PLACE_ORDER_URI = "http://localhost:7000/place-order";

	private static final String GET_MY_ORDER_URI = "http://localhost:7000/my-orders/";

	private static final String ADD_USER_RATING_URI = "http://localhost:8000/add-user-rating";

	private static final String GET_USER_RATING_URI = "http://localhost:8000/user-ratings/";

	private Map<Integer, BookDTO> booksMap = new LinkedHashMap<>();

	private Random random = new Random(99999999);

	@Override
	public List<String> getAuthorsList() {
		List<String> authorsList = new ArrayList<>();
		authorsList.add("All Authors");
		authorsList.add("Ram Niwash");
		authorsList.add("Pardeep Kumar");
		authorsList.add("Raghuvinder Singh");
		authorsList.add("Gautam Mehla");
		return authorsList;
	}

	@Override
	public List<String> getCategoryList() {
		List<String> catList = new ArrayList<>();
		catList.add("All Categories");
		catList.add("Web");
		catList.add("Spring");
		catList.add("Java");
		catList.add("Sport");
		return catList;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<BookDTO> getMyBooks(String author, String category) {

		if (author == null || author.isBlank()) {
			author = "All Authors";
		}
		if (category == null || category.isBlank()) {
			category = "All Categories";
		}

		// Invoke BookSearchMS
		RestTemplate bookSearchRest = new RestTemplate();
		String endpoint = new StringBuilder(BOOK_SEARCH_END_URI).append(author).append("/").append(category).toString();
		List<Map<?, ?>> list = bookSearchRest.getForObject(endpoint, List.class);
		List<BookDTO> bookList = new ArrayList<>();
		for (Map<?, ?> mymap : list) {
			BookDTO mybook = BookAdaptor.convertMapToBook(mymap);
			bookList.add(mybook);
			booksMap.put(mybook.getBookId(), mybook);
		}
		return bookList;
	}

	@Override
	public BookDTO getBookByBookId(Integer bookId) {
		return booksMap.get(bookId);
	}

	@Override
	public BookInfo getBookInfoByBookId(Integer bookId) {
		RestTemplate bookSearchRest = new RestTemplate();
		String endpoint = new StringBuilder(GET_BOOK_BY_BOOK_ID_URI).append(bookId).toString();
		BookInfo bookInfo = bookSearchRest.getForObject(endpoint, BookInfo.class);
		return bookInfo;
	}

	@Override
	public void placeOrder(Map<Integer, BookDTO> mycartMap, String userId) {

		List<OrderItemDTO> itemList = new ArrayList<>();
		double totalPrice = 0.0;
		int totalQuantity = 0;

		// Generating random order id
		int orderId = random.nextInt(100, 99999999);
		for (BookDTO mybook : mycartMap.values()) {
			Integer bookId = mybook.getBookId();

			// Invoke BookPrice Controller
			RestTemplate bookPriceRest = new RestTemplate();
			String priceEndpoint = new StringBuilder(BOOK_PRICE_END_URI).append(bookId).toString();
			double offerPrice = bookPriceRest.getForObject(priceEndpoint, Double.class);
			OrderItemDTO item = new OrderItemDTO(random.nextInt(100, 99999999), orderId, bookId, 1, offerPrice);
			itemList.add(item);
			totalPrice = totalPrice + offerPrice;
			totalQuantity = totalQuantity + 1;
		}

		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm");
		String orderDate = formatter.format(today);

		OrderDTO order = new OrderDTO(orderId, orderDate, userId, totalQuantity, totalPrice, "New");
		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setOrder(order);
		orderInfo.setItemsList(itemList);

		// Invoke PlaceOrder MS
		RestTemplate orderRest = new RestTemplate();
		orderRest.postForEntity(PLACE_ORDER_URI, orderInfo, String.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OrderDTO> getMyOrders(String userId) {
		// Invoke PlaceOrder MS
		RestTemplate orderRest = new RestTemplate();
		String getOrderURI = new StringBuilder(GET_MY_ORDER_URI).append(userId).toString();
		List<OrderDTO> myorders = orderRest.getForObject(getOrderURI, List.class);
		return myorders;
	}

	@Override
	public void addUserRating(UserRatingDTO userRating) {
		userRating.setRatingId(random.nextInt(100, 99999999));
		RestTemplate ratingRest = new RestTemplate();
		ratingRest.put(ADD_USER_RATING_URI, userRating);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserRatingDTO> getMyRatings(String userId) {
		List<UserRatingDTO> ratingsList = new ArrayList<>();
		String ratingEndpoint = new StringBuilder(GET_USER_RATING_URI).append(userId).toString();
		RestTemplate ratingRest = new RestTemplate();
		List<Map<?, ?>> mymap = ratingRest.getForObject(ratingEndpoint, List.class);
		for (Map<?, ?> map : mymap) {
			UserRatingDTO urtaing = BookAdaptor.convertMapToUserRating(map);
			ratingsList.add(urtaing);
		}
		return ratingsList;
	}
}
