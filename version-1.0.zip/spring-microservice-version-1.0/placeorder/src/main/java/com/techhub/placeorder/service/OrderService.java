package com.techhub.placeorder.service;

import java.util.List;

import com.techhub.placeorder.dto.OrderDTO;
import com.techhub.placeorder.dto.OrderInfo;

public interface OrderService {

	public void placeOrder(OrderInfo orderInfo);

	public List<OrderDTO> getOrdersByUserId(String userId);
}
