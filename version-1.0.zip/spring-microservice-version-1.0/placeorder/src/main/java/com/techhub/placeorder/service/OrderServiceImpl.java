package com.techhub.placeorder.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.techhub.placeorder.adaptor.OrderAdaptor;
import com.techhub.placeorder.dto.OrderDTO;
import com.techhub.placeorder.dto.OrderInfo;
import com.techhub.placeorder.dto.OrderItemDTO;
import com.techhub.placeorder.model.BookInventory;
import com.techhub.placeorder.model.Order;
import com.techhub.placeorder.model.OrderItem;
import com.techhub.placeorder.repository.BookInventoryRepository;
import com.techhub.placeorder.repository.OrderItemRepository;
import com.techhub.placeorder.repository.OrderRepository;

import jakarta.annotation.PostConstruct;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {
	
	private static final String UPDATE_BOOK_INVENTORY_URI  = "http://localhost:5000/update-book-inventory";

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderItemRepository orderItemRepository;

	@Autowired
	private BookInventoryRepository bookInventoryRepository;
	
	@PostConstruct
	public void setup() {

		bookInventoryRepository.save(new BookInventory(1, 50));
		bookInventoryRepository.save(new BookInventory(2, 50));
		bookInventoryRepository.save(new BookInventory(3, 50));
		bookInventoryRepository.save(new BookInventory(4, 50));
		bookInventoryRepository.save(new BookInventory(5, 50));
		bookInventoryRepository.save(new BookInventory(6, 50));
		bookInventoryRepository.save(new BookInventory(7, 50));
		bookInventoryRepository.save(new BookInventory(8, 50));
		bookInventoryRepository.save(new BookInventory(9, 50));
		bookInventoryRepository.save(new BookInventory(10, 50));
		
		orderRepository.save(new Order(100, "10-Aug-2023", "U0001", 2, 898, "NEW"));
		orderRepository.save(new Order(101, "11-Aug-2023", "U0002", 1, 632, "NEW"));
		orderRepository.save(new Order(102, "12-Aug-2023", "U0002", 3, 632, "NEW"));
		
		orderItemRepository.save(new OrderItem(200,100, 5,  2, 898));
		orderItemRepository.save(new OrderItem(201,101, 6,  1, 632));
		orderItemRepository.save(new OrderItem(202,102, 7, 3, 632));
		
	}

	@Override
	public void placeOrder(OrderInfo orderInfo) {
		
		// 1. Save the Order
		OrderDTO orderDTO = orderInfo.getOrder();
		Order myorder = orderRepository.save(OrderAdaptor.toOrder(orderDTO)); 
		int orderId = myorder.getOrderId();
		
		// 2.Save OrderItems
		for (OrderItemDTO oitm : orderInfo.getItemsList()) {
			OrderItem orderItem = OrderAdaptor.toOrderItem(oitm);
			orderItem.setOrderId(orderId);
			orderItemRepository.save(orderItem);
		}
		
		// 3.Update Inventory at Two Places
		RestTemplate bookSearchRest = new RestTemplate();
		
		for (OrderItemDTO myitem : orderInfo.getItemsList()) {
			Integer bookId = myitem.getBookId();
			
			Optional<BookInventory> bookInventoryOpts = bookInventoryRepository.findById(bookId);
			
			if(bookInventoryOpts.isPresent()) {
				BookInventory bookInventory = bookInventoryOpts.get();				
				bookInventory.setBooksAvailable(bookInventory.getBooksAvailable() - 1);
				
				// 3A. Update Inventory of PlaceOrder Locally
				bookInventoryRepository.save(bookInventory);
				
				// 3B. Update Inventory of BookSearch Remotely
				bookSearchRest.put(UPDATE_BOOK_INVENTORY_URI, bookInventory);
			}
			
		}
	}

	@Override
	public List<OrderDTO> getOrdersByUserId(String userId) {
		List<Order> orderList = orderRepository.findOrdersByUserId(userId);
		return OrderAdaptor.toOrderDTOs(orderList);
	}
}