package com.techhub.userrating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserratingApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserratingApplication.class, args);
	}

}
