package com.techhub.userrating.adaptor;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.techhub.userrating.dto.BookRatingDTO;
import com.techhub.userrating.dto.UserRatingDTO;
import com.techhub.userrating.model.BookRating;
import com.techhub.userrating.model.UserRating;

public final class RatingAdaptor {

	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	private RatingAdaptor() {
	}

	public static final UserRating toUserRating(UserRatingDTO userRatingDTO) {
		return OBJECT_MAPPER.convertValue(userRatingDTO, UserRating.class);
	}

	public static final UserRatingDTO toUserRatingDTO(UserRating userRating) {
		return OBJECT_MAPPER.convertValue(userRating, UserRatingDTO.class);
	}
	
	public static final BookRatingDTO toBookRatingDTO(BookRating bookRating) {
		return OBJECT_MAPPER.convertValue(bookRating, BookRatingDTO.class);
	}

	public static final  List<UserRatingDTO> toUserRatingDtos(List<UserRating> userRatings) {
		List<UserRatingDTO> userRatingDTOs = new ArrayList<>();
		for (UserRating userRating : userRatings) {
			userRatingDTOs.add(toUserRatingDTO(userRating));
		}
		return userRatingDTOs;
	}
}
