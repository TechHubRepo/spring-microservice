package com.techhub.userrating.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.userrating.dto.BookRatingDTO;
import com.techhub.userrating.dto.UserRatingDTO;
import com.techhub.userrating.service.RatingService;

@CrossOrigin(origins = "*")
@RestController
public class RatingController {

	@Autowired
	private RatingService ratingService;

	@PutMapping("/add-user-rating")
	public void addUserRating(@RequestBody UserRatingDTO userRatingDTO) {
		ratingService.addUserRating(userRatingDTO);
	}

	@GetMapping("/user-ratings/{userId}")
	public List<UserRatingDTO> getUserRatingByUserId(@PathVariable String userId) {
		return ratingService.getUserRatingByUserId(userId);
	}

	@GetMapping("/book-ratings/{bookId}")
	public BookRatingDTO getBookRatingByBookId(@PathVariable Integer bookId) {
		return ratingService.getBookRatingByBookId(bookId);
	}
}
