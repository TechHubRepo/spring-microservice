package com.techhub.userrating.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.techhub.userrating.adaptor.RatingAdaptor;
import com.techhub.userrating.dto.BookRatingDTO;
import com.techhub.userrating.dto.UserRatingDTO;
import com.techhub.userrating.model.BookRating;
import com.techhub.userrating.model.UserRating;
import com.techhub.userrating.repository.BookRatingRepository;
import com.techhub.userrating.repository.UserRatingRepository;

@Service
@Transactional
public class RatingServiceImpl implements RatingService {

	private static final String UPDATE_BOOK_RATING_URI = "http://localhost:5000/update-book-rating";

	@Autowired
	private UserRatingRepository userRatingRepository;

	@Autowired
	private BookRatingRepository bookRatingRepository;

	@Override
	public void addUserRating(UserRatingDTO userRatingDTO) {

		// 1.Add the User Rating
		userRatingRepository.save(RatingAdaptor.toUserRating(userRatingDTO));

		// 2.Calculate the Avg rating for BookId
		int bookId = userRatingDTO.getBookId();
		List<UserRating> ratingList = userRatingRepository.findUserRatingByBookId(bookId);
		double sumRating = 0.0;
		for (UserRating ur : ratingList) {
			sumRating = sumRating + ur.getRating();
		}
		double avgRating = sumRating / ratingList.size();

		// 3.Update BookRating in UserRatingMS (Local)
		BookRating bookRating = bookRatingRepository.findBookRatingByBookId(bookId);
		if (bookRating == null) {
			bookRating = new BookRating();
			bookRating.setBookId(bookId);
			bookRating.setNumberOfSearches(1);
		}else {
			bookRating.setNumberOfSearches(bookRating.getNumberOfSearches()+1);
		}
		bookRating.setAvgRating(avgRating);
		bookRatingRepository.save(bookRating);

		// 4.Update BookRating in BookSearch (Remote) Invoking BookRating
		RestTemplate bookSearchRest = new RestTemplate();
		bookSearchRest.put(UPDATE_BOOK_RATING_URI, bookRating);
	}

	@Override
	public List<UserRatingDTO> getUserRatingByBookId(Integer bookId) {
		return RatingAdaptor.toUserRatingDtos(userRatingRepository.findUserRatingByBookId(bookId));
	}

	@Override
	public List<UserRatingDTO> getUserRatingByUserId(String userId) {
		return RatingAdaptor.toUserRatingDtos(userRatingRepository.findUserRatingByUserId(userId));
	}

	@Override
	public BookRatingDTO getBookRatingByBookId(Integer bookId) {
		return RatingAdaptor.toBookRatingDTO(bookRatingRepository.findBookRatingByBookId(bookId));
	}
}
