package com.techhub.bookprice.service;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.techhub.bookprice.adaptor.BookPriceAdaptor;
import com.techhub.bookprice.dto.BookPriceDTO;
import com.techhub.bookprice.model.BookPrice;
import com.techhub.bookprice.repository.BookPriceRepository;

import jakarta.annotation.PostConstruct;

@Service
@Transactional
public class BookPriceServiceImpl implements BookPriceService {

	private static final BookPriceDTO BOOK_PRICE_DTO = new BookPriceDTO(BigInteger.ZERO, 0, (byte) 0);

	@Autowired
	private BookPriceRepository bookPriceRepository;

	@PostConstruct
	public void setup() {
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(1), 500, (byte) 10));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(2), 400, (byte) 5));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(3), 600, (byte) 15));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(4), 300, (byte) 5));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(5), 900, (byte) 10));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(6), 1200, (byte) 20));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(7), 700, (byte) 10));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(8), 300, (byte) 25));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(9), 200, (byte) 10));
		bookPriceRepository.save(new BookPrice(BigInteger.valueOf(10), 1500, (byte) 30));
	}

	@Override
	public BookPriceDTO getBookPrice(BigInteger bookId) {
		Optional<BookPrice> bookPriceOptional = bookPriceRepository.findById(bookId);
		if (bookPriceOptional.isPresent()) {
			return BookPriceAdaptor.toBookPriceDTO(bookPriceOptional.get());
		}
		return BOOK_PRICE_DTO;
	}

	@Override
	public double getBookOfferedPrice(BigInteger bookId) {
		Optional<BookPrice> bookPriceOptional = bookPriceRepository.findById(bookId);
		if (bookPriceOptional.isPresent()) {
			BookPrice bookPrice = bookPriceOptional.get();
			double offerValue = (bookPrice.getBookPrice() * bookPrice.getBookOffer()) / 100;
			return bookPrice.getBookPrice() - offerValue;
		}
		return 0;
	}
}
