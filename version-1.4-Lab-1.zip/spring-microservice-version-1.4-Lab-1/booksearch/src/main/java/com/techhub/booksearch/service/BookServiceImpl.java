package com.techhub.booksearch.service;

import java.util.List;
import java.util.Optional;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.techhub.booksearch.adaptor.BookAdaptor;
import com.techhub.booksearch.config.Constant;
import com.techhub.booksearch.dto.BookDTO;
import com.techhub.booksearch.dto.BookInfo;
import com.techhub.booksearch.dto.BookInventoryDTO;
import com.techhub.booksearch.dto.BookPriceDTO;
import com.techhub.booksearch.dto.BookRatingDTO;
import com.techhub.booksearch.model.Book;
import com.techhub.booksearch.model.BookInventory;
import com.techhub.booksearch.model.BookRating;
import com.techhub.booksearch.repository.BookInventoryRepository;
import com.techhub.booksearch.repository.BookRatingRepository;
import com.techhub.booksearch.repository.BookRepository;
//import com.techhub.booksearch.util.BookPriceProxy;

import jakarta.annotation.PostConstruct;

@Repository
@Transactional
public class BookServiceImpl implements BookService {

//	private static final String BOOK_PRICE_URI = "http://localhost:4000/get-book-price/";

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private BookRatingRepository bookRatingRepository;

	@Autowired
	private BookInventoryRepository bookInventoryRepository;
	
//	@Autowired
//	private BookPriceProxy bookPriceProxy;
	
	@Autowired
	private DiscoveryClient discoveryClient;

	@PostConstruct
	public void setup() {

		bookRepository.save(new Book(1, "Master Spring Boot", "Ram Niwash", "TechHub Publication", "Spring"));
		bookRepository.save(new Book(2, "Master Angular", "Pardeep Kumar", "TechHub Publication", "Web"));
		bookRepository.save(new Book(3, "Master Angular", "Ram Niwash", "TechHub Publication", "Web"));
		bookRepository.save(new Book(4, "Master React", "Ram Niwash", "TechHub Publication", "Spring"));
		bookRepository.save(new Book(5, "Master Spring Framework", "Ram Niwash", "TechHub Publication", "Spring"));
		bookRepository.save(new Book(6, "Master Spring Security", "Pardeep Kumar", "TechHub Publication", "Spring"));
		bookRepository.save(new Book(7, "Master Vue JS", "Ram Niwash", "TechHub Publication", "Web"));
		bookRepository.save(new Book(8, "Node JS", "Raghuvinder Singh", "TechHub Publication", "Web"));
		bookRepository.save(new Book(9, "Master Core Java", "Ram Niwash", "TechHub Publication", "Java"));
		bookRepository.save(new Book(10, "Master Spring Rest", "Pardeep Kumar", "TechHub Publication", "Spring"));

		bookRatingRepository.save(new BookRating(1, 3.5, 99));
		bookRatingRepository.save(new BookRating(2, 3.5, 99));
		bookRatingRepository.save(new BookRating(3, 3.5, 99));
		bookRatingRepository.save(new BookRating(4, 3.5, 99));
		bookRatingRepository.save(new BookRating(5, 3.5, 99));
		bookRatingRepository.save(new BookRating(6, 3.5, 99));
		bookRatingRepository.save(new BookRating(7, 3.5, 99));
		bookRatingRepository.save(new BookRating(8, 3.5, 99));
		bookRatingRepository.save(new BookRating(9, 3.5, 99));
		bookRatingRepository.save(new BookRating(10, 3.5, 99));

		bookInventoryRepository.save(new BookInventory(1, 50));
		bookInventoryRepository.save(new BookInventory(2, 50));
		bookInventoryRepository.save(new BookInventory(3, 50));
		bookInventoryRepository.save(new BookInventory(4, 50));
		bookInventoryRepository.save(new BookInventory(5, 50));
		bookInventoryRepository.save(new BookInventory(6, 50));
		bookInventoryRepository.save(new BookInventory(7, 50));
		bookInventoryRepository.save(new BookInventory(8, 50));
		bookInventoryRepository.save(new BookInventory(9, 50));
		bookInventoryRepository.save(new BookInventory(10, 50));
	}

	@Override
	public List<BookDTO> getBooks(String author, String category) {

		List<BookDTO> bookDTOs = null;
		if (author.equals("All Authors") && category.equals("All Categories")) {
			bookDTOs = BookAdaptor.toBookDTOs(bookRepository.findAll());
		} else if (author.equals("All Authors") && !category.equals("All Categories")) {
			bookDTOs = BookAdaptor.toBookDTOs(bookRepository.getBooksByCategory(category));
		} else if (!author.equals("All Authors") && category.equals("All Categories")) {
			bookDTOs = BookAdaptor.toBookDTOs(bookRepository.getBooksByAuthor(author));
		} else {
			bookDTOs = BookAdaptor.toBookDTOs(bookRepository.getBooksByAuthorAndCategory(author, category));
		}
		return bookDTOs;
	}

	@Override
	public BookInfo getBookInfo(Integer bookId) {

		// 1. Book Details
		Book book = new Book();
		Optional<Book> bookOpts = bookRepository.findById(bookId);
		if (bookOpts.isPresent()) {
			book = bookOpts.get();
		}

		// 2. Book Rating Details
		BookRating bookRating = new BookRating();
		Optional<BookRating> bookRatingOpts = bookRatingRepository.findById(bookId);
		if (bookRatingOpts.isPresent()) {
			bookRating = bookRatingOpts.get();
		}

		// 3. Book Inventory Details
		BookInventory bookInventory = new BookInventory();
		Optional<BookInventory> bookInventoryOpts = bookInventoryRepository.findById(bookId);
		if (bookInventoryOpts.isPresent()) {
			bookInventory = bookInventoryOpts.get();
		}

		// 4.Book Price Details – Invoking BookPriceMS
		List<ServiceInstance> serviceInstances = discoveryClient.getInstances("bookprice");
		for(ServiceInstance serviceInstance : serviceInstances) {
			System.out.println(serviceInstance.getUri().toString());
		}
		String BOOK_PRICE_URI = serviceInstances.get(0).getUri().toString();
		RestTemplate bookPriceRest = new RestTemplate();
		String bookPriceEndPoint = new StringBuilder(BOOK_PRICE_URI).append("/get-book-price/").append(bookId).toString();
		BookPriceDTO bookPriceDTO = bookPriceRest.getForObject(bookPriceEndPoint, BookPriceDTO.class);
		
		return BookAdaptor.toBookInfo(book, bookRating, bookInventory, bookPriceDTO);
	}

	@RabbitListener(queues = Constant.BOOK_RATING_QUEUE_NAME)
	public void updateBookRating(BookRatingDTO bookRatingDTO) {
		System.out.println("BookSearch -> RabbitMQ Listener -> Update book rating");
		System.out.println("BookRatingDTO : " + bookRatingDTO);
		BookRating bookRating = BookAdaptor.toBookRating(bookRatingDTO);
		bookRatingRepository.save(bookRating);
	}

	@RabbitListener(queues = Constant.BOOK_INV_QUEUE_NAME)
	public void updateBookInventory(BookInventoryDTO bookInventoryDTO) {
		System.out.println("BookSearch -> RabbitMQ Listener -> Update book inventory");
		System.out.println("BookInventoryDTO : " + bookInventoryDTO);
		bookInventoryRepository.save(BookAdaptor.toBookInventory(bookInventoryDTO));
	}
}
