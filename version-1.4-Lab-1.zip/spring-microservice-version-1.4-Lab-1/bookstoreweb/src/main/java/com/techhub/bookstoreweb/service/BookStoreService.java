package com.techhub.bookstoreweb.service;

import java.util.List;
import java.util.Map;

import com.techhub.bookstoreweb.dto.BookDTO;
import com.techhub.bookstoreweb.dto.BookInfo;
import com.techhub.bookstoreweb.dto.OrderDTO;
import com.techhub.userrating.dto.UserRatingDTO;

public interface BookStoreService {

	public List<String> getAuthorsList();

	public List<String> getCategoryList();

	public List<BookDTO> getMyBooks(String author, String category);

	public BookDTO getBookByBookId(Integer bookId);

	public BookInfo getBookInfoByBookId(Integer bookId);

	public void placeOrder(Map<Integer, BookDTO> mycartMap, String userId);

	public List<OrderDTO> getMyOrders(String userId);

	public void addUserRating(UserRatingDTO userRating);

	public List<UserRatingDTO> getMyRatings(String userId);

}
