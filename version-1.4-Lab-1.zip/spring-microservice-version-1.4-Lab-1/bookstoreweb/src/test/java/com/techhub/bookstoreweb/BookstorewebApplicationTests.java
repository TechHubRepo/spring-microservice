package com.techhub.bookstoreweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstorewebApplicationTests {

	@Test
	void contextLoads() {
	}

}
