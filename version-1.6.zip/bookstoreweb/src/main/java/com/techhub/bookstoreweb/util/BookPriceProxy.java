package com.techhub.bookstoreweb.util;

import java.math.BigInteger;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "bookprice")
public interface BookPriceProxy {

	@GetMapping(value = "/book-price/get-book-offer-price/{bookId}")
	public double getBookOfferPrice(@PathVariable BigInteger bookId);
}
