package com.techhub.placeorder.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.placeorder.dto.OrderDTO;
import com.techhub.placeorder.service.OrderService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/place-order")
@RefreshScope
public class OrderController {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	private OrderService orderService;

	@GetMapping("/my-orders/{userId}")
	public List<OrderDTO> getOrdersByUserId(@PathVariable String userId) {
		LOGGER.info("Entering | Class = OrderController | method = getOrdersByUserId");
		List<OrderDTO> myoders = new ArrayList<>();
		try {
			myoders = orderService.getOrdersByUserId(userId);
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage(), exception);
		}
		return myoders;
	}
}
