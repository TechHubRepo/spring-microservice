package com.techhub.placeorder.adaptor;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.techhub.placeorder.dto.OrderDTO;
import com.techhub.placeorder.dto.OrderItemDTO;
import com.techhub.placeorder.model.Order;
import com.techhub.placeorder.model.OrderItem;

public final class OrderAdaptor {

	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	private OrderAdaptor() {
	}

	public static final OrderDTO toOrderDTO(Order order) {
		OrderDTO orderDTO = OBJECT_MAPPER.convertValue(order, OrderDTO.class);
		return orderDTO;
	}
	
	public static final Order toOrder(OrderDTO orderDTO) {
		Order order = OBJECT_MAPPER.convertValue(orderDTO, Order.class);
		return order;
	}
	
	public static final OrderItem toOrderItem(OrderItemDTO orderItemDTO) {
		OrderItem orderItem = OBJECT_MAPPER.convertValue(orderItemDTO, OrderItem.class);
		return orderItem;
	}

	public static final List<OrderDTO> toOrderDTOs(List<Order> orders) {
		List<OrderDTO> dtos = new ArrayList<>();
		for (Order o : orders) {
			dtos.add(toOrderDTO(o));
		}
		return dtos;
	}

}
