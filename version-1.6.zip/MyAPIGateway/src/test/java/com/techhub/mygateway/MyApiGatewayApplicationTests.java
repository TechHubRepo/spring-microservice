package com.techhub.mygateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
