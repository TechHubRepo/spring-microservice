package com.techhub.bookprice.controller;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.bookprice.dto.BookPriceDTO;
import com.techhub.bookprice.service.BookPriceService;

@RestController
@CrossOrigin(origins = "*")
public class BookPriceController {

	@Autowired
	private BookPriceService bookPriceService;

	@GetMapping(value = "/get-book-price/{bookId}")
	public BookPriceDTO getBookPrice(@PathVariable BigInteger bookId) {
		return bookPriceService.getBookPrice(bookId);
	}

	@GetMapping(value = "/get-book-offer-price/{bookId}")
	public double getBookOfferPrice(@PathVariable BigInteger bookId) {
		return bookPriceService.getBookOfferedPrice(bookId);
	}
}
