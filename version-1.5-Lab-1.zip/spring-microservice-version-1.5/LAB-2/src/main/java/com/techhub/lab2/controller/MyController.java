package com.techhub.lab2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@GetMapping("/all-books")
	public List<String> getAllBooks() {
		System.out.println("---MyController --- all-books()---");
		// Success Case
		List<String> booksList = new ArrayList<>();
		booksList.add("Java");
		booksList.add("Spring");
		booksList.add("Spring Boot");
		booksList.add("Angular");
		booksList.add("React");
		return booksList;
	}

	@GetMapping("/books/{author}")
	public List<String> getBooksByAuthor(@PathVariable String author) {
		System.out.println("---MyController --- getBooksByAuthor()---");
		// Problem Case
		if (author.equals("hello")) {
			throw new ArithmeticException();
		}
		return List.of("Java", "HTML");
	}
}
