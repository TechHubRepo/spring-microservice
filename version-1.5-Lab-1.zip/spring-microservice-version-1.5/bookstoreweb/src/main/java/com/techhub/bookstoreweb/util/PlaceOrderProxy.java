package com.techhub.bookstoreweb.util;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.techhub.bookstoreweb.dto.OrderDTO;

@FeignClient(name = "placeorder")
public interface PlaceOrderProxy {

	@GetMapping("/my-orders/{userId}")
	public List<OrderDTO> getOrdersByUserId(@PathVariable String userId);
}
