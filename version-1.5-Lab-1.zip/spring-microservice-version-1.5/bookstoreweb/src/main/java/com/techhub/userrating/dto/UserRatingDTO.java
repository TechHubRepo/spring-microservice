package com.techhub.userrating.dto;

import java.io.Serializable;
import java.math.BigInteger;

public class UserRatingDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private BigInteger ratingId;

	private Integer bookId;

	private String userId;

	private Integer rating;

	private String review;

	public UserRatingDTO() {
		super();
	}

	public UserRatingDTO(BigInteger ratingId, Integer bookId, String userId, Integer rating, String review) {
		super();
		this.ratingId = ratingId;
		this.bookId = bookId;
		this.userId = userId;
		this.rating = rating;
		this.review = review;
	}

	public BigInteger getRatingId() {
		return ratingId;
	}

	public void setRatingId(BigInteger ratingId) {
		this.ratingId = ratingId;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	@Override
	public String toString() {
		return "UserRating [ratingId=" + ratingId + ", bookId=" + bookId + ", userId=" + userId + ", rating=" + rating + ", review=" + review + "]";
	}
}
