package com.techhub.bookstoreweb.dto;

import java.util.List;

public class OrderInfo {

	private OrderDTO order;
	private List<OrderItemDTO> itemsList;

	public OrderInfo() {
		super();
	}

	public OrderInfo(OrderDTO order, List<OrderItemDTO> itemsList) {
		super();
		this.order = order;
		this.itemsList = itemsList;
	}

	public OrderDTO getOrder() {
		return order;
	}

	public void setOrder(OrderDTO order) {
		this.order = order;
	}

	public List<OrderItemDTO> getItemsList() {
		return itemsList;
	}

	public void setItemsList(List<OrderItemDTO> itemsList) {
		this.itemsList = itemsList;
	}

	@Override
	public String toString() {
		return "OrderInfo [order=" + order + ", itemsList=" + itemsList + "]";
	}
}
