package com.techhub.booksearch.adaptor;

import java.util.ArrayList;
import java.util.List;

import com.techhub.booksearch.dto.BookDTO;
import com.techhub.booksearch.dto.BookInfo;
import com.techhub.booksearch.dto.BookInventoryDTO;
import com.techhub.booksearch.dto.BookPriceDTO;
import com.techhub.booksearch.dto.BookRatingDTO;
import com.techhub.booksearch.model.Book;
import com.techhub.booksearch.model.BookInventory;
import com.techhub.booksearch.model.BookRating;

public final class BookAdaptor {

	private BookAdaptor() {
	}

	public static final BookDTO toBookDTO(Book book) {
		return new BookDTO(book.getBookId(), book.getBookName(), book.getAuthor(), book.getPublications(),
				book.getCategory());
	}
	
	public static final List<BookDTO> toBookDTOs(List<Book> books) {
		List<BookDTO> bookDTOs = new ArrayList<>();
		for (Book book : books) {
			bookDTOs.add(toBookDTO(book));
		}
		return bookDTOs;
	}

	public static final BookRating toBookRating(BookRatingDTO bookRatingDTO) {
		return new BookRating(bookRatingDTO.getBookId(), bookRatingDTO.getAvgRating(), bookRatingDTO.getNumberOfSearches());
	}

	public static final BookInventory toBookInventory(BookInventoryDTO bookInventoryDTO) {
		return new BookInventory(bookInventoryDTO.getBookId(), bookInventoryDTO.getBooksAvailable());
	}
	
	public static final BookInfo toBookInfo(Book book, BookRating bookRating, BookInventory bookInventory, BookPriceDTO bookPriceDTO) {
		
		BookInfo bookInfo = new BookInfo();
		
		bookInfo.setBookId(book.getBookId()); //1
		bookInfo.setBookName(book.getBookName());//2
		bookInfo.setAuthor(book.getAuthor()); //3
		bookInfo.setPublications(book.getPublications());//4
		bookInfo.setCategory(book.getCategory());//5
		
		bookInfo.setAvgRating(bookRating.getAvgRating());//6
		bookInfo.setNumberOfSearches(bookRating.getNumberOfSearches());//7
		
		bookInfo.setBooksAvailable(bookInventory.getBooksAvailable());//8
		
		bookInfo.setPrice(bookPriceDTO.getBookPrice());//9
		bookInfo.setOffer(bookPriceDTO.getBookOffer());//10
		
		return bookInfo;
	}
}
