package com.techhub.lab1.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("LAB-2")
public interface Lab2Proxy {

	@GetMapping("/all-books")
	public List<String> getAllBooks();
	
	@GetMapping("/books/{author}")
	public List<String> getBooksByAuthor(@PathVariable String author) ;
}
