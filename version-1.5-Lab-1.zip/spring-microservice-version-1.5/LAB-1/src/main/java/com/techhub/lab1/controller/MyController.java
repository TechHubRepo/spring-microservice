package com.techhub.lab1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.lab1.proxy.Lab2Proxy;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class MyController {

	@Autowired
	private Lab2Proxy lab2Proxy;

	@CircuitBreaker(name = "getMyBooks", fallbackMethod = "getMyBooksFallback")
	@GetMapping("/mybooks")
	public List<String> getMyBooks() {
		System.out.println("--- MyController --- getMyBooks() ---");
		List<String> booksList = lab2Proxy.getAllBooks();
		return booksList;
	}
	
	public List<String> getMyBooksFallback(Throwable throwable) {
//		System.out.println(throwable.getMessage());
		System.out.println("--- MyController --- getMyBooksFallback() ---");
		return List.of("No Books available");
	}	

	@CircuitBreaker(name = "getBooksByAuthor", fallbackMethod = "getBooksByAuthorFallback")
	@GetMapping("/mybooks/{author}")
	public List<String> getBooksByAuthor(@PathVariable String author) {
		System.out.println("--- MyController --- getBooksByAuthor() ---");
		List<String> booksList = lab2Proxy.getBooksByAuthor(author);
		return booksList;
	}

	public List<String> getBooksByAuthorFallback(String author, Throwable throwable) {
//		System.out.println(throwable.getMessage());
		System.out.println("--- MyController --- getBooksByAuthorFallback() --");
		List<String> booksList = new ArrayList<String>();
		booksList.add("No Books Available Currently for Author : " + author);
		return booksList;
	}
}
