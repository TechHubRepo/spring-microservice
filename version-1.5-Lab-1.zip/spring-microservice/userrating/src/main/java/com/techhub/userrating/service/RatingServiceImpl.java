package com.techhub.userrating.service;

import java.util.List;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.techhub.booksearch.dto.BookRatingDTO;
import com.techhub.userrating.adaptor.RatingAdaptor;
import com.techhub.userrating.config.Constant;
import com.techhub.userrating.dto.UserRatingDTO;
import com.techhub.userrating.model.BookRating;
import com.techhub.userrating.model.UserRating;
import com.techhub.userrating.repository.BookRatingRepository;
import com.techhub.userrating.repository.UserRatingRepository;

@Service
@Transactional
public class RatingServiceImpl implements RatingService {

//	private static final String UPDATE_BOOK_RATING_URI = "http://localhost:5000/update-book-rating";
	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private UserRatingRepository userRatingRepository;

	@Autowired
	private BookRatingRepository bookRatingRepository;

	@RabbitListener(queues = Constant.USER_RATING_QUEUE_NAME)
	public void addUserRating(UserRatingDTO userRatingDTO) {

		System.out.println("UserRating -> RabbitMQ Listener -> Add user rating");
		System.out.println("UserRatingDTO : " + userRatingDTO);

		// 1.Add the User Rating
		userRatingRepository.save(RatingAdaptor.toUserRating(userRatingDTO));

		// 2.Calculate the Avg rating for BookId
		int bookId = userRatingDTO.getBookId();
		List<UserRating> ratingList = userRatingRepository.findUserRatingByBookId(bookId);
		double sumRating = 0.0;
		for (UserRating ur : ratingList) {
			sumRating = sumRating + ur.getRating();
		}
		double avgRating = sumRating / ratingList.size();

		// 3.Update BookRating in UserRatingMS (Local)
		BookRating bookRating = bookRatingRepository.findBookRatingByBookId(bookId);
		if (bookRating == null) {
			bookRating = new BookRating();
			bookRating.setBookId(bookId);
		}
		bookRating.setAvgRating(avgRating);
		bookRating.setNumberOfSearches(bookRating.getNumberOfSearches() + 1);
		bookRatingRepository.save(bookRating);

		// 4.Update BookRating in BookSearch (Remote) Invoking BookRating
		BookRatingDTO bookRatingDTO = new BookRatingDTO();
		bookRatingDTO.setBookId(bookId);
		bookRatingDTO.setAvgRating(avgRating);
		bookRatingDTO.setNumberOfSearches(bookRating.getNumberOfSearches());
		rabbitTemplate.convertAndSend(Constant.BOOK_RATING_EXCHANGE_NAME, Constant.BOOK_RATING_ROUTING_KEY,
				bookRatingDTO);
	}

	@Override
	public List<UserRatingDTO> getUserRatingByBookId(Integer bookId) {
		return RatingAdaptor.toUserRatingDtos(userRatingRepository.findUserRatingByBookId(bookId));
	}

	@Override
	public List<UserRatingDTO> getUserRatingByUserId(String userId) {
		return RatingAdaptor.toUserRatingDtos(userRatingRepository.findUserRatingByUserId(userId));
	}

	@Override
	public BookRatingDTO getBookRatingByBookId(Integer bookId) {
		return RatingAdaptor.toBookRatingDTO(bookRatingRepository.findBookRatingByBookId(bookId));
	}
}
