package com.techhub.lab2.util;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.techhub.lab2.vo.BookPriceVo;

@FeignClient(name="LAB-3")
public interface Lab3Proxy {

	@GetMapping("/lab-3/book-price/{bookId}")
	public BookPriceVo getBookPriceById(@PathVariable Integer bookId) ;
}
