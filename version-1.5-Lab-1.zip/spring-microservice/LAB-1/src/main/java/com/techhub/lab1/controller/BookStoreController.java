package com.techhub.lab1.controller;

import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.lab1.proxy.Lab2Proxy;
import com.techhub.lab1.vo.BookInfo;

@RestController
@RequestMapping(value = "/lab-1")
public class BookStoreController {

	@Value("${server.port}")
	private String serverPort;

	@Autowired
	private Lab2Proxy lab2Proxy;

	@GetMapping("/mybooks/{bookId}")
	public BookInfo getMyBooks(@PathVariable Integer bookId) {
		System.out.println("PORT = "+this.serverPort+" ---> BookStoreController  ----> getMyBooks : " + bookId);
		BookInfo booksInfo = lab2Proxy.getBook(bookId);
		String info = "LAB 1 port number is " + this.serverPort + "-" + booksInfo.getInfo();
		booksInfo.setInfo(info);
		System.out.println("LAB-1 Exiting :  TIME : "+LocalTime.now());
		return booksInfo;
	}
}
