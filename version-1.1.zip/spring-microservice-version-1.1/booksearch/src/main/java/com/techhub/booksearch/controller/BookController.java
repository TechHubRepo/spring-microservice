package com.techhub.booksearch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.booksearch.dto.BookDTO;
import com.techhub.booksearch.dto.BookInfo;
import com.techhub.booksearch.dto.BookInventoryDTO;
import com.techhub.booksearch.dto.BookRatingDTO;
import com.techhub.booksearch.service.BookService;


@CrossOrigin(origins = "*", allowedHeaders = "*", methods = { RequestMethod.GET, RequestMethod.PUT })
@RestController
public class BookController {

	@Autowired
	private BookService bookService;

	@GetMapping("/search-books/{author}/{category}")
	public List<BookDTO> searchBooks(@PathVariable String author, @PathVariable String category) {
		return bookService.getBooks(author, category);
	}

	@GetMapping("/get-book/{bookId}")
	public BookInfo getBookById(@PathVariable Integer bookId) {
		return bookService.getBookInfo(bookId);
	}

	@PutMapping("/update-book-rating")
	public void updateBookRating(@RequestBody BookRatingDTO bookRatingDTO) {
		System.out.println("BookRatingDTO :" + bookRatingDTO);
		bookService.updateBookRating(bookRatingDTO);
	}

	@PutMapping("/update-book-inventory")
	public void updateBookInventory(@RequestBody BookInventoryDTO bookInventoryDTO) {
		bookService.updateBookInventory(bookInventoryDTO);
	}
}
