package com.techhub.userrating.service;

import java.util.List;

import com.techhub.userrating.dto.BookRatingDTO;
import com.techhub.userrating.dto.UserRatingDTO;

public interface RatingService {

	public void addUserRating(UserRatingDTO userRating);

	public List<UserRatingDTO> getUserRatingByBookId(Integer bookId);

	public List<UserRatingDTO> getUserRatingByUserId(String userId);

	public BookRatingDTO getBookRatingByBookId(Integer bookId);
}
