package com.techhub.mybootadminserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import de.codecentric.boot.admin.server.config.EnableAdminServer;

@EnableAdminServer
@SpringBootApplication
public class MyBootAdminServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBootAdminServerApplication.class, args);
	}
}
