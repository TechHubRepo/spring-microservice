package com.techhub.booksearch.dto;

import java.io.Serializable;

public class BookRatingDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer bookId;

	private Double avgRating;

	private Integer numberOfSearches;

	public BookRatingDTO() {
		super();
	}

	public BookRatingDTO(Integer bookId, Double avgRating, Integer numberOfSearches) {
		super();
		this.bookId = bookId;
		this.avgRating = avgRating;
		this.numberOfSearches = numberOfSearches;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public Double getAvgRating() {
		return avgRating;
	}

	public void setAvgRating(Double avgRating) {
		this.avgRating = avgRating;
	}

	public Integer getNumberOfSearches() {
		return numberOfSearches;
	}

	public void setNumberOfSearches(Integer numberOfSearches) {
		this.numberOfSearches = numberOfSearches;
	}

	@Override
	public String toString() {
		return "BookRating [bookId=" + bookId + ", avgRating=" + avgRating + ", numberOfSearches=" + numberOfSearches
				+ "]";
	}
}
