package com.techhub.userrating.config;

public final class Constant {

	private Constant() {
	}

	/** Book Rating exchange, query and key */
	
	public static final String BOOK_RATING_EXCHANGE_NAME = "my-book-rating-exc";

	public static final String BOOK_RATING_QUEUE_NAME = "my-book-rating-queue";
	
	public static final String BOOK_RATING_ROUTING_KEY = "my.book.rating.key";
	
	/** User Rating exchange, query and key */
	
	public static final String USER_RATING_EXCHANGE_NAME = "my-user-rating-exc";

	public static final String USER_RATING_QUEUE_NAME = "my-user-rating-queue";
	
	public static final String USER_RATING_ROUTING_KEY = "my.user.rating.key";
	
}
