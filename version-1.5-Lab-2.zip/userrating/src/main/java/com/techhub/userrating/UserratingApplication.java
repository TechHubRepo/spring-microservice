package com.techhub.userrating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class UserratingApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserratingApplication.class, args);
	}
}