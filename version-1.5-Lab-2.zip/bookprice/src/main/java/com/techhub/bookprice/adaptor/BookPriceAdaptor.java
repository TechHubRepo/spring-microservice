package com.techhub.bookprice.adaptor;

import com.techhub.bookprice.dto.BookPriceDTO;
import com.techhub.bookprice.model.BookPrice;

public final class BookPriceAdaptor {

	private BookPriceAdaptor() {
	}

	public static final BookPrice toBookPrice(BookPriceDTO bookPriceDTO) {
		return new BookPrice(bookPriceDTO.getBookId(), bookPriceDTO.getBookPrice(), bookPriceDTO.getBookOffer());
	}

	public static final BookPriceDTO toBookPriceDTO(BookPrice bookPrice) {
		return new BookPriceDTO(bookPrice.getBookId(), bookPrice.getBookPrice(), bookPrice.getBookOffer());
	}

}
