package com.techhub.lab3.vo;

public class BookPriceVo {

	private int bookId;

	private int bookPrice;

	private int bookOffer;

	private String info;

	public BookPriceVo() {
		super();
	}

	public BookPriceVo(int bookId, int bookPrice, int bookOffer) {
		super();
		this.bookId = bookId;
		this.bookPrice = bookPrice;
		this.bookOffer = bookOffer;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public int getBookOffer() {
		return bookOffer;
	}

	public void setBookOffer(int bookOffer) {
		this.bookOffer = bookOffer;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	@Override
	public String toString() {
		return "BookPriceVo [bookId=" + bookId + ", bookPrice=" + bookPrice + ", bookOffer=" + bookOffer + ", info="
				+ info + "]";
	}
}
