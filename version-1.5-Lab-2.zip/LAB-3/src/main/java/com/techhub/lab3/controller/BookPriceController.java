package com.techhub.lab3.controller;

import java.time.LocalTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.lab3.vo.BookPriceVo;

@RestController
@RequestMapping(value = "/lab-3")
public class BookPriceController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BookPriceController.class);

	@Value("${server.port}")
	private String serverPort;

	@GetMapping("/book-price/{bookId}")
	public BookPriceVo getBookPriceById(@PathVariable Integer bookId) {
		LOGGER.info("PORT = "+this.serverPort+" ---> BookPriceController  --->  getBookPriceById : "+bookId);
		BookPriceVo bookPriceVo = new BookPriceVo(bookId, 200, 8);
		bookPriceVo.setInfo("LAB 3 port number is " + this.serverPort);
		LOGGER.info("LAB-3 Exiting getBookPriceById :  TIME : "+LocalTime.now());
		return bookPriceVo;
	}
}
