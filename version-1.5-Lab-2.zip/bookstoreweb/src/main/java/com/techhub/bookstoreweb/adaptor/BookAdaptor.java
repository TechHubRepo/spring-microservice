package com.techhub.bookstoreweb.adaptor;

import java.math.BigInteger;
import java.util.Map;

import com.techhub.bookstoreweb.dto.BookDTO;
import com.techhub.userrating.dto.UserRatingDTO;

public final class BookAdaptor {

	private BookAdaptor() {
	}

	public static final UserRatingDTO convertMapToUserRating(Map<?, ?> map) {

		UserRatingDTO rating = new UserRatingDTO();
		BigInteger ratingId = new BigInteger(map.get("ratingId").toString());
		rating.setRatingId(ratingId);
		rating.setUserId(map.get("userId").toString());
		rating.setBookId(Integer.valueOf(map.get("bookId").toString()));
		rating.setRating(Integer.valueOf(map.get("rating").toString()));
		rating.setReview(map.get("review").toString());
		return rating;
	}

	public static final BookDTO convertMapToBook(Map<?, ?> map) {
		BookDTO mybook = new BookDTO();
		mybook.setBookId(Integer.parseInt(map.get("bookId").toString()));
		mybook.setBookName((map.get("bookName").toString()));
		mybook.setAuthor((map.get("author").toString()));
		mybook.setPublications(map.get("publications").toString());
		mybook.setCategory(map.get("category").toString());
		return mybook;
	}
}
