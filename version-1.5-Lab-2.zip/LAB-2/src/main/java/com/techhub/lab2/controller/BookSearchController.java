package com.techhub.lab2.controller;

import java.time.LocalTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.lab2.util.Lab3Proxy;
import com.techhub.lab2.vo.BookInfo;
import com.techhub.lab2.vo.BookPriceVo;

@RestController
@RequestMapping(value = "/lab-2")
public class BookSearchController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BookSearchController.class);

	@Value("${server.port}")
	private String serverPort;

	@Autowired
	private Lab3Proxy lab3Proxy;

	@GetMapping("/get-book/{bookId}")
	public BookInfo getBook(@PathVariable Integer bookId) {
		LOGGER.info("PORT = " + this.serverPort + " ----> BookPriceController  ----> getBook : bookId=" + bookId);
		BookPriceVo bookPriceVo = lab3Proxy.getBookPriceById(bookId);
		BookInfo bookInfo = new BookInfo();
		bookInfo.setAuthor("Ram Niwash");
		bookInfo.setPublications("TechHub");
		bookInfo.setBookId(bookId);
		bookInfo.setBookName("Spring Microservice Course");
		bookInfo.setCategory("Technology");
		bookInfo.setNumberOfSearches(50);
		bookInfo.setBooksAvailable(100);
		bookInfo.setAvgRating(8);
		bookInfo.setPrice(bookPriceVo.getBookPrice());
		bookInfo.setOffer(bookPriceVo.getBookOffer());
		String info = "LAB 2 port number is " + this.serverPort + "-" + bookPriceVo.getInfo();
		bookInfo.setInfo(info);
		LOGGER.info("LAB-2 Exiting getBook :  TIME : " + LocalTime.now());
		return bookInfo;
	}

	@GetMapping("/get-book-by-author/{author}")
	public BookInfo getBookByAuthor(@PathVariable String author) {
		LOGGER.info("PORT = " + this.serverPort + " ----> BookPriceController  ----> getBookByAuthor : author =" + author);
		try {
			throw new NullPointerException("My Demo Exception");
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.info("LAB-2 Exiting getBookByAuthor :  TIME : " + LocalTime.now());
		return null;
	}

}
